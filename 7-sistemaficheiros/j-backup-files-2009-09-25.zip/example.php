<?php
/*
Copyright: http://www.website-design-software-india.com
You are free to distribute the code, use it, make changes to it to suit your requirements, 
but you should not claim it to be yours
In case you distribute it, please keep this copyright box intact.
Thanks
*/
$e="E_ALL ~E_NOTICE"; error_reporting($e);
require_once 'backup.class';
$z= new BackUP;

$z->source_dir= 'test/original/';
$z->target_dir= 'test/new/';
$z->file_created= 'test/backup.szip';

echo '<p> Creating a backup of: '. $z->source_dir. '</p>';
echo '<p> Extracting the backup to: '. $z->target_dir. '</p>';



echo "<p> <a href='". $z->file_created. "' target='_blank'> Backup File </a> is: ". $z->make_backup(). " MB </p>";

// to extract the backed file
$z->load_backup();
echo '<h4> Scanning target location: </h4> <pre>'; print_r($z->result); echo '</pre>';

?>